﻿namespace Travel.Entities.Items
{
	public class BottleCaps : Item
	{
		public BottleCaps()
			: base(30000)
		{
		}
	}
}