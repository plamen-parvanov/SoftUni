﻿namespace Travel.Entities.Items
{
	public class Ring : Item
	{
		public Ring()
			: base(1000)
		{
		}
	}
}