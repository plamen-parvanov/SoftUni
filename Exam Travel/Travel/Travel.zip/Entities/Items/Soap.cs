﻿namespace Travel.Entities.Items
{
	public class Soap : Item
	{
		public Soap()
			: base(int.MaxValue)
		{
		}
	}
}