﻿namespace Travel.Entities.Items
{
	public class Tissues : Item
	{
		public Tissues()
			: base(2)
		{
		}
	}
}