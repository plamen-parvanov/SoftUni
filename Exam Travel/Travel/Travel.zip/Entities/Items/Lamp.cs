﻿namespace Travel.Entities.Items
{
	public class Lamp : Item
	{
		public Lamp()
			: base(4)
		{
		}
	}
}