﻿namespace Travel.Entities.Items
{
	public class PenDrive : Item
	{
		public PenDrive()
			: base(25)
		{
		}
	}
}