﻿namespace Travel.Entities.Items
{
	public class Watch : Item
	{
		public Watch()
			: base(300)
		{
		}
	}
}