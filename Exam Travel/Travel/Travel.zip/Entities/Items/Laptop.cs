﻿namespace Travel.Entities.Items
{
	public class Laptop : Item
	{
		public Laptop()
			: base(value: 3000)
		{
		}
	}
}