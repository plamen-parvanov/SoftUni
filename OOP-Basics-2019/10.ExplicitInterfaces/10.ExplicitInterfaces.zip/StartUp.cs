﻿namespace _10.ExplicitInterfaces
{
    using Controllers;

    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}
