﻿public class OutOfFuelException : CustomException
{
    public override string Message => "Out of fuel";
}
