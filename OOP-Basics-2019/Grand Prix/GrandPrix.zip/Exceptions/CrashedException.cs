﻿public class CrashedException : CustomException
{
    public override string Message => "Crashed";
}
