﻿using System;

public class CustomException : Exception
{ 
}
