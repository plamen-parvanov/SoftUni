﻿public class BlownTyreException : CustomException
{
    public override string Message => "Blown Tyre";
}
