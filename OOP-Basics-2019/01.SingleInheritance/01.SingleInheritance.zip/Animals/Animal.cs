﻿namespace Farm.Animals
{
    public class Animal
    {
        public void Eat() => System.Console.WriteLine("eating...");
    }
}
