﻿namespace _05.Mordor_sCruelPlan.Enums
{
    public enum Food
    {
        Cram = 2,
        Lembas = 3,
        Apple = 1,
        Melon = 1,
        HoneyCake = 5,
        Mushrooms = -10,
        EverythingElse = -1
    }
}
