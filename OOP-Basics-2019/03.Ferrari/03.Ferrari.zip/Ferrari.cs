﻿namespace _03.Ferrari
{
    using _03.Ferrari.Contracts;

    public class Ferrari : ICar
    {
        public Ferrari(string driverName)
        {
            this.DriverName = driverName;
        }

        public string Model => "488-Spider";

        public string DriverName { get; private set; }

        public string PushTheGasPedal()
        {
            return "Brakes!";
        }

        public string UseBrakes()
        {
            return "Zadu6avam sA!";
        }

        public override string ToString()
        {
            return $"{this.Model}/{this.PushTheGasPedal()}/{this.UseBrakes()}/{this.DriverName}";
        }
    }
}
