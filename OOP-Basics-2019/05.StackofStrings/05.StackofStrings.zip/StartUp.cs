﻿namespace CustomStack
{
    public class StartUp
    {
        public static void Main()
        {

        }
    }
}
