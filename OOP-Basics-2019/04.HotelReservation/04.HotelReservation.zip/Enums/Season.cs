﻿namespace _04.HotelReservation.Enums
{
    public enum Season
    {
        Autumn = 1,
        Spring,
        Winter,
        Summer
    }
}
