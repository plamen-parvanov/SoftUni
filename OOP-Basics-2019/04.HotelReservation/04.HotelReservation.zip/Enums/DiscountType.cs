﻿namespace _04.HotelReservation.Enums
{
    public enum DiscountType
    {
        None,
        SecondVisit = 10,
        VIP = 20
    }
}
