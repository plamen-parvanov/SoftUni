﻿namespace _06.Animals
{
    public interface ISoundProducable
    {
        string ProduceSound();
    }
}
