﻿namespace StorageMaster
{
    using Core;

    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}
