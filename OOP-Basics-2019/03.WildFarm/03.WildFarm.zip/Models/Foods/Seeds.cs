﻿namespace _03.WildFarm.Models.Foods
{
    public class Seeds : Food
    {
        public Seeds(string name, int quantity) : base(name, quantity)
        {
        }
    }
}
