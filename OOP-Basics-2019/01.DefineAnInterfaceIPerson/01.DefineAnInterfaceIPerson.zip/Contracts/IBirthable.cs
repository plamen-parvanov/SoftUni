﻿namespace PersonInfo.Contracts
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
