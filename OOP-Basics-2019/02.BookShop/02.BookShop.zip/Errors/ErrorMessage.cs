﻿namespace _02.BookShop.Errors
{
    public static class ErrorMessage
    {
        public static string InvalidArgument => "{0} not valid!";
    }
}
