﻿namespace _08.MilitaryElite.Contracts
{
    public interface IId
    {
        string Id { get; }
    }
}
