﻿namespace _08.MilitaryElite.Contracts
{
    public interface ISalary
    {
        decimal Salary { get; }
    }
}
