﻿namespace _08.MilitaryElite.Contracts
{
    public interface IName
    {
        string FirstName { get; }

        string LastName { get; }
    }
}
