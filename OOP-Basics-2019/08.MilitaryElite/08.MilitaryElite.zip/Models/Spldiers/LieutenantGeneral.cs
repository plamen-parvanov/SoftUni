﻿namespace _08.MilitaryElite.Models
{
    using System.Collections.Generic;
    using System.Text;

    public class LieutenantGeneral : Private
    {
        private List<Private> privates;

        public LieutenantGeneral(string id, string firstName, string lastName, 
            decimal salary, List<Private> privates)
            : base(id, firstName, lastName, salary)
        {
            this.privates = privates;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();

            sb.AppendLine(base.ToString());
            sb.AppendLine("Privates:");

            //could be problem if list is empty!!!
            this.privates.ForEach(p => sb.AppendLine("  " + p.ToString()));

            return sb.ToString().TrimEnd();
        }
    }
}
