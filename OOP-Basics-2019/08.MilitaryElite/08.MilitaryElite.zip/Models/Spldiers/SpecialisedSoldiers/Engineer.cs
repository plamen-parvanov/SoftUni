﻿namespace _08.MilitaryElite.Models.SpecialisedSoldiers
{
    using System.Collections.Generic;
    using System.Text;
    using Models.Repairs;

    public class Engineer : SpecialisedSoldier
    {
        private List<Repair> repairs;

        public Engineer(string id, string firstName, string lastName,
            decimal salary, string corp, List<Repair> repairs)
            : base(id, firstName, lastName, salary, corp)
        {
            this.repairs = repairs;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();

            sb.AppendLine(base.ToString());
            sb.AppendLine("Repairs:");

            //could be problem if list is empty!!!
            repairs.ForEach(r => sb.AppendLine(r.ToString()));

            return sb.ToString().TrimEnd();
        }
    }
}
