﻿namespace _08.MilitaryElite.Models.Spldiers.SpecialisedSoldiers
{
    using Models.Missions;
    using System.Collections.Generic;
    using System.Text;

    public class Commando : SpecialisedSoldier
    {
        private List<Mission> missions;

        public Commando(string id, string firstName, string lastName, 
            decimal salary, string corp, List<Mission> missions)
            : base(id, firstName, lastName, salary, corp)
        {
            this.missions = missions;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();

            sb.AppendLine(base.ToString());
            sb.AppendLine("Missions:");
            
            //could be a problem if list is empty!!!
            missions.ForEach(m => sb.AppendLine(m.ToString()));

            return sb.ToString().TrimEnd();
        }
    }
}
