﻿namespace _04.Telephony.Contracts
{
    interface IBrowseable
    {
        string Browsing();
    }
}
