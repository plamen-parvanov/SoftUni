﻿namespace _04.Telephony.Contracts
{
    public interface ICallable
    {
        string Calling();
    }
}
