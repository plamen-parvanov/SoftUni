﻿namespace _05.BorderControl.Contracts
{
    public interface IId
    {
        string Id { get; }
    }
}
