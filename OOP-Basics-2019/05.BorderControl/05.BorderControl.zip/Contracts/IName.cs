﻿namespace _05.BorderControl.Contracts
{
    public interface IName
    {
        string Name { get; }
    }
}
