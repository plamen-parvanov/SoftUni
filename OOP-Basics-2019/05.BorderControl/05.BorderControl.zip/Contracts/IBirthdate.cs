﻿namespace _05.BorderControl.Contracts
{
    interface IBirthdate
    {
        string Birthdate { get; }
    }
}
