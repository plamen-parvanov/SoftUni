﻿namespace SoftUniRestaurant
{
    using Core;

    public class StartUp
    {
        public static void Main()
        {
            var restaurantController = new RestaurantController();
            var engine = new Engine(restaurantController);
            engine.Run();
        }
    }
}
