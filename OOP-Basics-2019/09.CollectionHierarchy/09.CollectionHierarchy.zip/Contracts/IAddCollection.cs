﻿namespace _09.CollectionHierarchy.Contracts
{
    public interface IAddCollection
    {
        int Add(string item);
    }
}
