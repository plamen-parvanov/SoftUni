﻿namespace _04.ShoppingSpree.Errors
{
    public static class ErrorMessage
    {
        public static string InvalidName => "{0} cannot be empty";

        public static string InvalidMoney => "Money cannot be negative";
    }
}
