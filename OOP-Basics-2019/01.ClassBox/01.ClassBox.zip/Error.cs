﻿namespace _01.ClassBox
{
    public static class Error
    {
        public static string InvalidArgument => "{0} cannot be zero or negative.";
    }
}
