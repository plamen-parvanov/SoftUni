﻿namespace _03._Test_Client
{
    using System;
    using System.Collections.Generic;

    public class Problem03
    {
        private static Dictionary<int, BankAccount> dict;

        public static void Main()
        {
            dict = new Dictionary<int, BankAccount>();

            while (true)
            {
                var inputLine = Console.ReadLine();
                if (inputLine == "End")
                {
                    break;
                }

                ExecuteCommand(inputLine);
            }
        }

        private static void ExecuteCommand(string inputLine)
        {
            var arr = inputLine.Split();
            var command = arr[0];
            var id = int.Parse(arr[1]);

            switch (command)
            {
                case "Create":
                    CreateAccount(id);
                    break;
                case "Deposit":
                    var deposit = decimal.Parse(arr[2]);
                    MakeDeposit(id, deposit);
                    break;
                case "Withdraw":
                    var withdraw = decimal.Parse(arr[2]);
                    MakeWithdraw(id, withdraw);
                    break;
                case "Print":
                    PrintAccountInfoFor(id);
                    break;
            }
        }

        private static void PrintAccountInfoFor(int id)
        {
            if (!dict.ContainsKey(id))
            {
                Console.WriteLine("Account does not exist");
                return;
            }

            var balance = dict[id].Balance;
            Console.WriteLine($"Account ID{id}, balance {balance:F2}");
        }

        private static void MakeWithdraw(int id, decimal amount)
        {
            if (!dict.ContainsKey(id))
            {
                Console.WriteLine("Account does not exist");
                return;
            }
            else if (dict[id].Balance < amount)
            {
                Console.WriteLine("Insufficient balance");
                return;
            }

            dict[id].Withdraw(amount);
        }

        private static void MakeDeposit(int id, decimal amount)
        {
            if (!dict.ContainsKey(id))
            {
                Console.WriteLine("Account does not exist");
                return;
            }

            dict[id].Deposit(amount);
        }

        private static void CreateAccount(int id)
        {
            if (dict.ContainsKey(id))
            {
                Console.WriteLine("Account already exists");
            }
            else
            {
                var currAccount = new BankAccount();
                currAccount.Id = id;
                dict.Add(id, currAccount);

            }
        }
    }
}
