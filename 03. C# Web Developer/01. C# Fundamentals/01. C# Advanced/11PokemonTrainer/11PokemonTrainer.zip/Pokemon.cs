﻿public class Pokemon
{
    public string name;
    public string element;
    public int health;

    public Pokemon(string name, string element, int healt)
    {
        this.name = name;
        this.element = element;
        this.health = healt;
    }
}
