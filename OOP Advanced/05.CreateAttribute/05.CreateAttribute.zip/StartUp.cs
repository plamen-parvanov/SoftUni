﻿[SoftUni(name: "Plamen")]
public class StartUp
{
    [SoftUni(name: "Parvanov")]
    public static void Main()
    {

    }
}