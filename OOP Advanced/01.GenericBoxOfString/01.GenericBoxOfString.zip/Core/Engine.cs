﻿namespace _01.GenericBoxOfString.Core
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Models;

    public class Engine
    {
      public void Run()
        {
            var list = new List<Box<double>>();

            AddingItemsToList(list);

            var box = new Box<double>(double.Parse(Console.ReadLine()));

            Console.WriteLine(CountGreaterElement(list, box));

            //SwapPositionsInList(list);

            //PrintList(list);
        }

        private void PrintList(List<Box<string>> list)
        {
            list.ForEach(b => Console.WriteLine(b));
        }

        private void SwapPositionsInList(List<Box<int>> list)
        {
            var input = Console.ReadLine();
            var indexes = input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                               .Select(int.Parse)
                               .ToArray();

            var firstIndex = indexes[0];
            var secondIndex = indexes[1];

            var tempBox = list[firstIndex];

            list[firstIndex] = list[secondIndex];
            list[secondIndex] = tempBox;
        }       

        private void AddingItemsToList(List<Box<double>> list)
        {
            var n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                var value = double.Parse(Console.ReadLine());

                var currentBox = new Box<double>(value);

                list.Add(currentBox);
            }
        }

        private int CountGreaterElement(List<Box<double>> list, Box<double> box)
        {
            var result = list.Where(b => b.CompareTo(box) > 0).Count();

            return result;
        }
    }
}
