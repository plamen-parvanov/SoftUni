﻿namespace _06.TrafficLights
{
    public enum Signal
    {
        Red = 0,
        Green =1,
        Yellow = 2
    }
}
