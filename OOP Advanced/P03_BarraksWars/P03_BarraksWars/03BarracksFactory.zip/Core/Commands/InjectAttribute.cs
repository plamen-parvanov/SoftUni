﻿namespace _03BarracksFactory.Core.Commands
{
    using System;

    public class InjectAttribute : Attribute
    {
    }
}
